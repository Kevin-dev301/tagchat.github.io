<div class="chat-ui-messages" id="messs">
    <div class="chat-ui-right chat-all-card">
        <div class="chat-ui-right-message message-card">
            <p class="message-text">
                <a href="" class="">https://yifysubtitles.org/subtitles/captain-america-the-first-avenger-2011-english-yify-83966</a>
            </p>
            <div class="chat-ui-right-message message-options">
                <button class="copy-btn" title="Copy Message">
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 24">
                        <path d="M4 2C2.895 2 2 2.895 2 4L2 18L4 18L4 4L18 4L18 2L4 2 z M 8 6C6.895 6 6 6.895 6 8L6 20C6 21.105 6.895 22 8 22L20 22C21.105 22 22 21.105 22 20L22 8C22 6.895 21.105 6 20 6L8 6 z M 8 8L20 8L20 20L8 20L8 8 z" />
                    </svg>
                </button>
                <p class="read">
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 24">
                        <path d="M15.980469 6.9902344 A 1.0001 1.0001 0 0 0 15.292969 7.2929688L11.455078 11.130859 A 1.0001 1.0001 0 1 0 12.869141 12.544922L16.707031 8.7070312 A 1.0001 1.0001 0 0 0 15.980469 6.9902344 z M 21.980469 6.9902344 A 1.0001 1.0001 0 0 0 21.292969 7.2929688L12 16.585938L8.7070312 13.292969 A 1.0001 1.0001 0 1 0 7.2929688 14.707031L11.292969 18.707031 A 1.0001 1.0001 0 0 0 12.707031 18.707031L22.707031 8.7070312 A 1.0001 1.0001 0 0 0 21.980469 6.9902344 z M 1.9902344 12.990234 A 1.0001 1.0001 0 0 0 1.2929688 14.707031L4.5449219 17.960938 A 1.0012744 1.0012744 0 1 0 5.9609375 16.544922L2.7070312 13.292969 A 1.0001 1.0001 0 0 0 1.9902344 12.990234 z" />
                    </svg>
                </p>
                <p class="time">
                    Sunday, 20/03/2022 19:35
                </p>
                <p class="composer">
                    You
                </p>
            </div>
        </div>
        <div class="chat-ui-right-img chat-ui-img">
            <img src="../../../assets/avatar-1.jpg" alt="">
        </div>
    </div>
    <div class="chat-ui-left chat-all-card">
        <div class="chat-ui-img">
            <img src="../../../assets/avatar-1.jpg" alt="">
        </div>
        <div class="message-card">
            <p class="message-text">Lorem Ipsum</p>
            <div class="message-options">
                <p class="composer">
                    You
                </p>
                <p class="time">
                    Sunday, 20/03/2022 19:35
                </p>
                <p class="read">
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 24">
                        <path d="M15.980469 6.9902344 A 1.0001 1.0001 0 0 0 15.292969 7.2929688L11.455078 11.130859 A 1.0001 1.0001 0 1 0 12.869141 12.544922L16.707031 8.7070312 A 1.0001 1.0001 0 0 0 15.980469 6.9902344 z M 21.980469 6.9902344 A 1.0001 1.0001 0 0 0 21.292969 7.2929688L12 16.585938L8.7070312 13.292969 A 1.0001 1.0001 0 1 0 7.2929688 14.707031L11.292969 18.707031 A 1.0001 1.0001 0 0 0 12.707031 18.707031L22.707031 8.7070312 A 1.0001 1.0001 0 0 0 21.980469 6.9902344 z M 1.9902344 12.990234 A 1.0001 1.0001 0 0 0 1.2929688 14.707031L4.5449219 17.960938 A 1.0012744 1.0012744 0 1 0 5.9609375 16.544922L2.7070312 13.292969 A 1.0001 1.0001 0 0 0 1.9902344 12.990234 z" />
                    </svg>
                </p>
                <button class="copy-btn" title="Copy Message">
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 24">
                        <path d="M4 2C2.895 2 2 2.895 2 4L2 18L4 18L4 4L18 4L18 2L4 2 z M 8 6C6.895 6 6 6.895 6 8L6 20C6 21.105 6.895 22 8 22L20 22C21.105 22 22 21.105 22 20L22 8C22 6.895 21.105 6 20 6L8 6 z M 8 8L20 8L20 20L8 20L8 8 z" />
                    </svg>
                </button>
            </div>
        </div>
    </div>
    <div class="chat-ui-right chat-all-card">
        <div class="chat-ui-right-message  message-card">
            <div class="image-card">
                <img src="../../../assets/avatar-1.jpg" alt="">
            </div>
            <div class="chat-ui-right-message message-options">
                <p class="read">
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 24">
                        <path d="M15.980469 6.9902344 A 1.0001 1.0001 0 0 0 15.292969 7.2929688L11.455078 11.130859 A 1.0001 1.0001 0 1 0 12.869141 12.544922L16.707031 8.7070312 A 1.0001 1.0001 0 0 0 15.980469 6.9902344 z M 21.980469 6.9902344 A 1.0001 1.0001 0 0 0 21.292969 7.2929688L12 16.585938L8.7070312 13.292969 A 1.0001 1.0001 0 1 0 7.2929688 14.707031L11.292969 18.707031 A 1.0001 1.0001 0 0 0 12.707031 18.707031L22.707031 8.7070312 A 1.0001 1.0001 0 0 0 21.980469 6.9902344 z M 1.9902344 12.990234 A 1.0001 1.0001 0 0 0 1.2929688 14.707031L4.5449219 17.960938 A 1.0012744 1.0012744 0 1 0 5.9609375 16.544922L2.7070312 13.292969 A 1.0001 1.0001 0 0 0 1.9902344 12.990234 z" />
                    </svg>
                </p>
                <p class="time">
                    Sunday, 20/03/2022 19:35
                </p>
                <p class="composer">
                    You
                </p>
            </div>
        </div>
        <div class="chat-ui-right-img chat-ui-img">
            <img src="../../../assets/avatar-1.jpg" alt="">
        </div>
    </div>
    <div class="chat-ui-left chat-all-card">
        <div class="chat-ui-right-img chat-ui-img">
            <img src="../../../assets/avatar-1.jpg" alt="">
        </div>
        <div class="chat-ui-right-message  message-card">
            <div class="image-card">
                <img src="../../../assets/avatar-1.jpg" alt="">
            </div>
            <div class="message-options">
                <p class="composer">
                    You
                </p>
                <p class="time">
                    Sunday, 20/03/2022 19:35
                </p>
                <p class="read">
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 24">
                        <path d="M15.980469 6.9902344 A 1.0001 1.0001 0 0 0 15.292969 7.2929688L11.455078 11.130859 A 1.0001 1.0001 0 1 0 12.869141 12.544922L16.707031 8.7070312 A 1.0001 1.0001 0 0 0 15.980469 6.9902344 z M 21.980469 6.9902344 A 1.0001 1.0001 0 0 0 21.292969 7.2929688L12 16.585938L8.7070312 13.292969 A 1.0001 1.0001 0 1 0 7.2929688 14.707031L11.292969 18.707031 A 1.0001 1.0001 0 0 0 12.707031 18.707031L22.707031 8.7070312 A 1.0001 1.0001 0 0 0 21.980469 6.9902344 z M 1.9902344 12.990234 A 1.0001 1.0001 0 0 0 1.2929688 14.707031L4.5449219 17.960938 A 1.0012744 1.0012744 0 1 0 5.9609375 16.544922L2.7070312 13.292969 A 1.0001 1.0001 0 0 0 1.9902344 12.990234 z" />
                    </svg>
                </p>
            </div>
        </div>
    </div>
    <div class="chat-ui-left chat-all-card">
        <div class="chat-ui-right-img chat-ui-img">
            <img src="../../../assets/avatar-1.jpg" alt="">
        </div>
        <div class="chat-ui-right-message  message-card">
            <div class="image-card">
                <video controls>
                    <source src="../../../assets/videos/mov_bbb.mp4">
                    Sorry, Your Browser Doesn't Support Videos
                </video>
            </div>
            <div class="message-options">
                <p class="composer">
                    You
                </p>
                <p class="time">
                    Sunday, 20/03/2022 19:35
                </p>
                <p class="read">
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 24">
                        <path d="M15.980469 6.9902344 A 1.0001 1.0001 0 0 0 15.292969 7.2929688L11.455078 11.130859 A 1.0001 1.0001 0 1 0 12.869141 12.544922L16.707031 8.7070312 A 1.0001 1.0001 0 0 0 15.980469 6.9902344 z M 21.980469 6.9902344 A 1.0001 1.0001 0 0 0 21.292969 7.2929688L12 16.585938L8.7070312 13.292969 A 1.0001 1.0001 0 1 0 7.2929688 14.707031L11.292969 18.707031 A 1.0001 1.0001 0 0 0 12.707031 18.707031L22.707031 8.7070312 A 1.0001 1.0001 0 0 0 21.980469 6.9902344 z M 1.9902344 12.990234 A 1.0001 1.0001 0 0 0 1.2929688 14.707031L4.5449219 17.960938 A 1.0012744 1.0012744 0 1 0 5.9609375 16.544922L2.7070312 13.292969 A 1.0001 1.0001 0 0 0 1.9902344 12.990234 z" />
                    </svg>
                </p>
            </div>
        </div>
    </div>
    <div class="chat-ui-right chat-all-card">
        <div class="chat-ui-right-message  message-card">
            <div class="image-card">
                <video controls>
                    <source src="../../../assets/videos/mov_bbb.mp4">
                    Sorry, Your Browser Doesn't Support Videos
                </video>
            </div>
            <div class="chat-ui-right-message message-options">
                <p class="read">
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 24">
                        <path d="M15.980469 6.9902344 A 1.0001 1.0001 0 0 0 15.292969 7.2929688L11.455078 11.130859 A 1.0001 1.0001 0 1 0 12.869141 12.544922L16.707031 8.7070312 A 1.0001 1.0001 0 0 0 15.980469 6.9902344 z M 21.980469 6.9902344 A 1.0001 1.0001 0 0 0 21.292969 7.2929688L12 16.585938L8.7070312 13.292969 A 1.0001 1.0001 0 1 0 7.2929688 14.707031L11.292969 18.707031 A 1.0001 1.0001 0 0 0 12.707031 18.707031L22.707031 8.7070312 A 1.0001 1.0001 0 0 0 21.980469 6.9902344 z M 1.9902344 12.990234 A 1.0001 1.0001 0 0 0 1.2929688 14.707031L4.5449219 17.960938 A 1.0012744 1.0012744 0 1 0 5.9609375 16.544922L2.7070312 13.292969 A 1.0001 1.0001 0 0 0 1.9902344 12.990234 z" />
                    </svg>
                </p>
                <p class="time">
                    Sunday, 20/03/2022 19:35
                </p>
                <p class="composer">
                    You
                </p>
            </div>
        </div>
        <div class="chat-ui-right-img chat-ui-img">
            <img src="../../../assets/avatar-1.jpg" alt="">
        </div>
    </div>
    <div class="chat-ui-left chat-all-card">
        <div class="chat-ui-right-img chat-ui-img">
            <img src="../../../assets/avatar-1.jpg" alt="">
        </div>
        <div class="chat-ui-right-message message-card">
            <div class="audio-card">
                <audio controls>
                    <source src="../../../assets/audio/Pop Smoke - Dior (Bonus).mp3">
                    Sorry, Your Browser Doesn't Support Videos
                </audio>
            </div>
            <div class="message-options">
                <p class="composer">
                    You
                </p>
                <p class="time">
                    Sunday, 20/03/2022 19:35
                </p>
                <p class="read">
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 24">
                        <path d="M15.980469 6.9902344 A 1.0001 1.0001 0 0 0 15.292969 7.2929688L11.455078 11.130859 A 1.0001 1.0001 0 1 0 12.869141 12.544922L16.707031 8.7070312 A 1.0001 1.0001 0 0 0 15.980469 6.9902344 z M 21.980469 6.9902344 A 1.0001 1.0001 0 0 0 21.292969 7.2929688L12 16.585938L8.7070312 13.292969 A 1.0001 1.0001 0 1 0 7.2929688 14.707031L11.292969 18.707031 A 1.0001 1.0001 0 0 0 12.707031 18.707031L22.707031 8.7070312 A 1.0001 1.0001 0 0 0 21.980469 6.9902344 z M 1.9902344 12.990234 A 1.0001 1.0001 0 0 0 1.2929688 14.707031L4.5449219 17.960938 A 1.0012744 1.0012744 0 1 0 5.9609375 16.544922L2.7070312 13.292969 A 1.0001 1.0001 0 0 0 1.9902344 12.990234 z" />
                    </svg>
                </p>
            </div>
        </div>
    </div>
    <div class="chat-ui-right chat-all-card">
        <div class="chat-ui-right-message  message-card">
            <div class="audio-card">
                <audio controls>
                    <source src="../../../assets/audio/Pop Smoke - Dior (Bonus).mp3">
                    Sorry, Your Browser Doesn't Support Videos
                </audio>
            </div>
            <div class="chat-ui-right-message message-options">
                <p class="read">
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 24">
                        <path d="M15.980469 6.9902344 A 1.0001 1.0001 0 0 0 15.292969 7.2929688L11.455078 11.130859 A 1.0001 1.0001 0 1 0 12.869141 12.544922L16.707031 8.7070312 A 1.0001 1.0001 0 0 0 15.980469 6.9902344 z M 21.980469 6.9902344 A 1.0001 1.0001 0 0 0 21.292969 7.2929688L12 16.585938L8.7070312 13.292969 A 1.0001 1.0001 0 1 0 7.2929688 14.707031L11.292969 18.707031 A 1.0001 1.0001 0 0 0 12.707031 18.707031L22.707031 8.7070312 A 1.0001 1.0001 0 0 0 21.980469 6.9902344 z M 1.9902344 12.990234 A 1.0001 1.0001 0 0 0 1.2929688 14.707031L4.5449219 17.960938 A 1.0012744 1.0012744 0 1 0 5.9609375 16.544922L2.7070312 13.292969 A 1.0001 1.0001 0 0 0 1.9902344 12.990234 z" />
                    </svg>
                </p>
                <p class="time">
                    Sunday, 20/03/2022 19:35
                </p>
                <p class="composer">
                    You
                </p>
            </div>
        </div>
        <div class="chat-ui-right-img chat-ui-img">
            <img src="../../../assets/avatar-1.jpg" alt="">
        </div>
    </div>
</div>